def deco(function):
    print("avant")
    function()
    print("après")


@deco
def hello_world():
    print("Hello world!")


hello_world()
